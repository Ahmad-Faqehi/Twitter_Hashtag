<?php include("init.php"); ?>
<?php if(!$session->is_signed_in()){redirect("login.php");} ?>
<?php 
$user = User::find_by_id($session->user_id);
if($user->user_roal != 1)
{
  $session->logout();
  redirect("login.php");
}
 ?>
<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
  

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?php echo $page_title ?></title>

  <!-- Custom fonts for this template-->
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@700&display=swap" rel="stylesheet">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/process.js"></script>
  
  <!-- Custom styles for this template-->
  <link href="css/mystyle.css" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>