<?php
require_once "admin/includes/config.php";
require_once "admin/includes/database.php";
require_once "admin/includes/Db_object.php";
require_once "admin/includes/function.php";
require_once "admin/includes/user.php";
require_once "admin/includes/hashtag.php";

?>